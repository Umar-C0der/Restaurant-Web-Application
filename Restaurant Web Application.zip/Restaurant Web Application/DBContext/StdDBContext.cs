﻿using Final_Project_of_WAD.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Final_Project_of_WAD.DBContext
{
    public class StdDBContext : IdentityDbContext<ApplicationUser>
    {
        public StdDBContext(DbContextOptions<StdDBContext> options) : base(options)
        {

        }
        public DbSet<formData> formData { get; set; }
    
    }
}
