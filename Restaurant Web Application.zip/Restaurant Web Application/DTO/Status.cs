﻿namespace Final_Project_of_WAD.DTO
{
    public class Status
    {
        public int StatuCode { get; set; }
        public string Message { get; set; }
    }
}
