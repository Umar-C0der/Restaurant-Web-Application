﻿using Microsoft.Build.Framework;

namespace Final_Project_of_WAD.DTO
{
    public class LoginModel
    {
        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }
    }
}
