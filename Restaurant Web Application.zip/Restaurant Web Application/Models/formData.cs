﻿using System.ComponentModel.DataAnnotations;

namespace Final_Project_of_WAD.Models
{
    public class formData
    {
      
            [Key]

            public string Iid { get; set; }

            public string name { get; set; }
            public string categorie { get; set; }
            public string size { get; set; }
            public int price { get; set; }


        
    }
}
