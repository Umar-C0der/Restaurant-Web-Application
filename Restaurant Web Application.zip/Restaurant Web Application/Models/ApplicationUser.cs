﻿using MessagePack;
using Microsoft.AspNetCore.Identity;

namespace Final_Project_of_WAD.Models
{
    public class ApplicationUser : IdentityUser
    {
        
        public string Name { get; set; }

        public string ? ProfilePicture { get; set; }
    }
}
