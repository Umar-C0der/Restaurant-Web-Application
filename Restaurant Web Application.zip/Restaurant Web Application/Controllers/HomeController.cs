﻿using Final_Project_of_WAD.DBContext;
using Final_Project_of_WAD.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;





namespace WAD_Project.Controllers
{
    public class HomeController : Controller
    {
        private readonly StdDBContext _Db; 
        public HomeController(StdDBContext Db)
        {
            _Db = Db;
        }
        [Authorize]
        public IActionResult Index()
        {
            return View();
        }
        [Authorize(Roles = "admin")]
        [HttpGet]
        public IActionResult form()
        {

            return View();
        }
        [Authorize(Roles = "admin")]
        [HttpPost]
        public IActionResult form(formData data)
        {
            var id = _Db.formData.Where(x => x.Iid == data.Iid).FirstOrDefault();
            if (id != null)
            {
                @ViewData["messege"] = "The id is allready taken choose an other one!";

            }
            else
            {
                _Db.formData.Add(data);
                _Db.SaveChanges();

            }
            return View();
        }

        [Authorize(Roles = "admin")]
        public IActionResult list()
        {
            var listifData = _Db.formData.ToList();

            return View(listifData);

        }

        [Authorize(Roles = "admin")]
        public IActionResult Delete(string id)
        {
            var data = _Db.formData.Where(x => x.Iid == id).FirstOrDefault();
            _Db.formData.Remove(data);
            _Db.SaveChanges();
            return RedirectToAction("list");
        }

        [Authorize(Roles = "admin")]
        public ActionResult Details(string id)
        {
            var data = _Db.formData.Where(x => x.Iid == id).FirstOrDefault();
            return View(data);
        }

        [Authorize(Roles = "admin")]
        [HttpGet]
        public ActionResult Edit(string id)
        {
            var data = _Db.formData.Where(x => x.Iid == id).FirstOrDefault();
            return View(data);
        }
        [Authorize(Roles = "admin")]
        [HttpPost]
        public ActionResult Edit(formData modle)
        {
            var data = _Db.formData.Where(x => x.Iid == modle.Iid).FirstOrDefault();
            if (data != null)
            {
                data.Iid = modle.Iid;
                data.name = modle.name;
                data.categorie = modle.categorie;
                data.price = modle.price;
                data.size = modle.size;
                _Db.SaveChanges();

            }
            return View();
        }

        public IActionResult FoodList()
        {
            var listifData = _Db.formData.ToList();

            return View(listifData);

        }

    }
}