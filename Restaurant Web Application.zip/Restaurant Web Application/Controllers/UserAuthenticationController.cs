﻿using Final_Project_of_WAD.DTO;
using Final_Project_of_WAD.Repositories.Abstract;
using Microsoft.AspNetCore.Mvc;

namespace Final_Project_of_WAD.Controllers
{
    public class UserAuthenticationController : Controller
    {
        private readonly IUserAuthenticationService _service;
        public UserAuthenticationController(IUserAuthenticationService service)
        {
            this._service =service;
                
        }
        [HttpGet]
        public IActionResult Registration()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Registration(Registration model)
        {
           if (!ModelState.IsValid)
                return View(model);
            model.Role = "user";
            var result = await _service.RedistrationAsync(model);
            TempData["mag"] = result.Message;
            return RedirectToAction(nameof(Registration));
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
     
        public async Task<IActionResult> Login(LoginModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var result = await _service.LoginAsync(model);
            if (result.StatuCode == 1)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                TempData["msg"]= result.Message;
                return RedirectToAction(nameof(Login)); 
            }
        }

        public async Task<IActionResult> Logout()
        {
            await _service.logoutAsync();
            return RedirectToAction(nameof(Login));
        }

       // public async Task<IActionResult> Reg()
       //{
       //     var model = new Registration
       //     {
       //         Username = "zahid",
       //         Name = "Zahid Malik",
       //         Email = "zahid@gmail.com",
       //         Password = "Zahid@12345"
       //     };
       //     model.Role = "admin";
       //     var result = await _service.RedistrationAsync(model);
       //     return Ok(result);
       // }


    }

    
}
