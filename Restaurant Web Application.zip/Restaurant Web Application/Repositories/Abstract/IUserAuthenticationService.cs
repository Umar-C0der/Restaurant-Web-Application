﻿using Final_Project_of_WAD.DTO;

namespace Final_Project_of_WAD.Repositories.Abstract
{
    public interface IUserAuthenticationService
    {
        Task<Status> LoginAsync(LoginModel model);
        Task<Status> RedistrationAsync(Registration model);
        Task logoutAsync();
    }
}
